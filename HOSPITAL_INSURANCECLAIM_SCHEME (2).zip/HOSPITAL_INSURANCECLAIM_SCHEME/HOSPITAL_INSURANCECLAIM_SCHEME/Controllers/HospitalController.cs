﻿using HOSPITAL_INSURANCECLAIM_SCHEME.Models;
using HOSPITAL_INSURANCECLAIM_SCHEME.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using PdfSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using TheArtOfDev.HtmlRenderer.PdfSharp;

namespace HOSPITAL_INSURANCECLAIM_SCHEME.Controllers
{
    public class HospitalController : Controller
    {
        private readonly IInsuranceClaimService _insurance;
        public HospitalController(IInsuranceClaimService insurance)
        {
            _insurance = insurance;
        }
        public async Task<IActionResult> InsuranceApply()
        {
            List<HospitalEntity> lstHospital = new List<HospitalEntity>();
            lstHospital = await _insurance.GetHospitalService();
            lstHospital.Insert(0, new HospitalEntity { Hosp_ID = 0, Hosp_Name = "Please Select Hospital" });
            ViewBag.Hospital = lstHospital;
            return View();
        }
        public async Task<JsonResult> Doct_Bind(int Hosp_ID)
        {
            var subcatList = await _insurance.GetDoctorService(Hosp_ID);
            List<SelectListItem> scalist = new List<SelectListItem>();
            foreach (DoctorEntity dr in subcatList)
            {
                scalist.Add(new SelectListItem { Text = dr.Doct_Name, Value = dr.Doct_ID.ToString() });
            }
            var jsonres = JsonConvert.SerializeObject(scalist);
            return Json(jsonres);
        }
        public async Task<JsonResult> Patient_Bind(int Doct_ID)
        {
            var subcatList = await _insurance.GetPatientService(Doct_ID);
            List<SelectListItem> scalist = new List<SelectListItem>();
            foreach (PatientEntity dr in subcatList)
            {
                scalist.Add(new SelectListItem { Text = dr.Patient_Name, Value = dr.Patient_ID.ToString() });
            }
            var jsonres = JsonConvert.SerializeObject(scalist);
            return Json(jsonres);
        }
        public async Task<JsonResult> Insurance_Bind(int Patient_ID)
        {
            var subcatList = await _insurance.GetInsuranceDetailService(Patient_ID);
            var jsonres = JsonConvert.SerializeObject(subcatList);
            return Json(jsonres);
        }

        public async Task<JsonResult> GetInsuranceDetail()
        {
            var subcatList = await _insurance.GetDetailsService();
            var jsonres = JsonConvert.SerializeObject(subcatList);
            return Json(jsonres);
        }
        [HttpPost]
        public async Task<JsonResult> InsertInsurance(PatientDetailsEntity se)
        {
            int data = await _insurance.InsertService(se);
            return Json(data);
        }

        public async Task GeneratePDFAsync(int id)
        {
            try
            {
                PdfSharpCore.Pdf.PdfDocument document = new PdfSharpCore.Pdf.PdfDocument();

                PatientDetailsEntity detail = await _insurance.FillCertificateService(id);

                string htmlcontent = "<div class='col-lg-12'>";
                htmlcontent += " <div style='width:550px; height:350px; padding:20px; text-align:center; border:10px solid #673AB7; margin-left:10%;'>";
                htmlcontent += " <div style= 'width:420px; height:300px;padding:20px; text-align:center; border:5px solid #673AB7;border-style:dotted;'>";
                if (detail != null)
                {
                    htmlcontent += " <span style='font-size:50px; font-weight:bold;  color:#663ab7;'>" + detail.Insurance_Name + "</span>";
                }
                htmlcontent += " <hr>";
                htmlcontent += "<span style='font-size:25px;'><i>Under Scheme:</i>" + detail.Insurance_Scheme_Name + "</span>";
                htmlcontent += "<br><br>";
                if (detail != null)
                {
                    htmlcontent += "<span style=''><b>" + detail.Patient_Name + "</b></span><br/><br/>";
                }
                if (detail != null)
                {
                    htmlcontent += "<span style='font-size:15px;'><i>Admission Date:" + detail.Admission_Date.Trim() + "</i></span> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style='font-size:15px;'><i>Discharge Date:" + detail.Discharge_Date.Trim() + "</i></span> <br/><br/>";
                }

                htmlcontent += " <div style='width:350px; height:50px; padding:20px; text-align:center; border:2px solid; margin-left:2%; margin-right:2%;'>";
                htmlcontent += "<span style='font-size:13px;'><i>Hospital code:" + detail.Hosp_ID + "</i></span> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style='font-size:13px;'><i>Hospital Name:" + detail.Hosp_Name + "</i></span> <br/><br/>";
                htmlcontent += "<span style='font-size:13px;'><i>Doctor code:" + detail.Doct_ID + "</i></span> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style='font-size:13px;'><i>Doctor Name :" + detail.Doct_Name + "</i></span> <br/><br/>";
                htmlcontent += "<span style='font-size:13px;'><i>Patient Code:" + detail.Patient_ID + "</i></span> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style='font-size:13px;'><i>Patient Name :" + detail.Patient_Name + "</i></span> <br/><br/>";
                htmlcontent += "</div>";

                htmlcontent += "<br /><br />";
                htmlcontent += "<span style='fs-30'><i>Total Expenses:</i>" + detail.Total_Expenses + "</span> <br>";
                htmlcontent += "<span style='fs-30'><i>Insured Amount:</i>" + detail.Insured_amount + "</span> <br>";
                htmlcontent += "<span style='fs-30'><i>Total Payble Amount:</i>" + detail.Total_Payble_Amount + "</span> <br>";
                htmlcontent += "<br /><br />";
                htmlcontent += " <hr>";
                htmlcontent += "<span style='fs-17' ><b>4th Floor OCAC Tower,Acharya Vihar, Bhubaneswar, Odisha </b></span>";
                htmlcontent += "</div>";
                htmlcontent += "</div>";



                PdfGenerator.AddPdfPages(document, htmlcontent, (PdfSharpCore.PageSize)PageSize.A4);

                byte[]? response = null;
                var stream = new MemoryStream();
                document.Save(stream);
                response = stream.ToArray();
                Response.Clear();
                string Filename = "Medical Discharge Report" + ".pdf";
                Response.Headers.Add("content-disposition", "attachment;" + Filename);
                Response.ContentType = "application/pdf";
                ValueTask valueTask = Response.Body.WriteAsync(response);
                Response.Body.Flush();
            }
            catch (Exception ex)
            {
               
            }
        }

    }
}
