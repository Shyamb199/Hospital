﻿using HOSPITAL_INSURANCECLAIM_SCHEME.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HOSPITAL_INSURANCECLAIM_SCHEME.Repository
{
    public interface IInsuranceClaimRepository
    {
        Task<List<HospitalEntity>> GetHospital();
        Task<List<DoctorEntity>> GetDoctor(int Hosp_ID);
        Task<List<PatientEntity>> GetPatient(int Doct_ID);
        Task<InsuranceEntity> GetInsuranceDetail(int Patient_ID);
        Task<List<PatientDetailsEntity>> GetDetails();
        Task<int> Insert(PatientDetailsEntity obj);
        Task<PatientDetailsEntity> FillCertificate(int id);
    }
}
