﻿using HOSPITAL_INSURANCECLAIM_SCHEME.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace HOSPITAL_INSURANCECLAIM_SCHEME.Repository
{
    public class InsuranceClaimRepository:BaseRepository, IInsuranceClaimRepository
    {
        public SqlCommand cm;
        public SqlDataAdapter da;
        public DataTable dt;
        public InsuranceClaimRepository(IConfiguration configuration) : base(configuration)
        {
        }
        public async Task<List<HospitalEntity>> GetHospital()
        {
            try
            {
                var cn = CreateConnection();
                if (cn.State == ConnectionState.Closed) cn.Open();
                cm = new SqlCommand();
                cm.Connection = cn;
                cm.CommandType = CommandType.StoredProcedure;
                cm.CommandText = "SP_Hospital";
                cm.Parameters.AddWithValue("@Action", "BH");
                da = new SqlDataAdapter(cm);
                dt = new DataTable();
                da.Fill(dt);
                var Hospital = (from DataRow dr in dt.Rows
                            select new HospitalEntity()
                            {
                                Hosp_ID = Convert.ToInt32(dr["Hosp_ID"].ToString()),
                                Hosp_Name = dr["Hosp_Name"].ToString(),
                            }).ToList();
                cn.Close();
                return Hospital;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public async Task<List<DoctorEntity>> GetDoctor(int Hosp_ID)
        {
            try
            {
                var cn = CreateConnection();
                if (cn.State == ConnectionState.Closed) cn.Open();
                cm = new SqlCommand();
                cm.Connection = cn;
                cm.CommandType = CommandType.StoredProcedure;
                cm.CommandText = "SP_Hospital";
                cm.Parameters.AddWithValue("@Action", "BD");
                cm.Parameters.AddWithValue("@Hosp_ID", Hosp_ID);
                da = new SqlDataAdapter(cm);
                dt = new DataTable();
                da.Fill(dt);
                var Doctor = (from DataRow dr in dt.Rows
                                select new DoctorEntity()
                                {
                                    Doct_ID = Convert.ToInt32(dr["Doct_ID"].ToString()),
                                    Doct_Name = dr["Doct_Name"].ToString(),
                                }).ToList();
                cn.Close();
                return Doctor;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public async Task<List<PatientEntity>> GetPatient(int Doct_ID)
        {
            try
            {
                var cn = CreateConnection();
                if (cn.State == ConnectionState.Closed) cn.Open();
                cm = new SqlCommand();
                cm.Connection = cn;
                cm.CommandType = CommandType.StoredProcedure;
                cm.CommandText = "SP_Hospital";
                cm.Parameters.AddWithValue("@Action", "BP");
                cm.Parameters.AddWithValue("@Doct_ID", Doct_ID);
                da = new SqlDataAdapter(cm);
                dt = new DataTable();
                da.Fill(dt);
                var Patient = (from DataRow dr in dt.Rows
                                select new PatientEntity()
                                {
                                    Patient_ID = Convert.ToInt32(dr["Patient_ID"].ToString()),
                                    Patient_Name = dr["Patient_Name"].ToString(),
                                }).ToList();
                cn.Close();
                return Patient;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public async Task<InsuranceEntity> GetInsuranceDetail(int Patient_ID)
        {
            try
            {
                var cn = CreateConnection();
                if (cn.State == ConnectionState.Closed) cn.Open();
                cm = new SqlCommand();
                cm.Connection = cn;
                cm.CommandType = CommandType.StoredProcedure;
                cm.CommandText = "SP_Hospital";
                cm.Parameters.AddWithValue("@Action", "BID");
                cm.Parameters.AddWithValue("@Patient_ID", Patient_ID);
                da = new SqlDataAdapter(cm);
                dt = new DataTable();
                da.Fill(dt);
                var Patient = (from DataRow dr in dt.Rows
                               select new InsuranceEntity()
                               {
                                   Insurance_Name = dr["Insurance_Name"].ToString(),
                                   Insurance_Scheme_Name = dr["Insurance_Scheme_Name"].ToString(),
                               }).FirstOrDefault();
                cn.Close();
                return Patient;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public async Task<List<PatientDetailsEntity>> GetDetails()
        {
            try
            {
                var cn = CreateConnection();
                if (cn.State == ConnectionState.Closed) cn.Open();
                cm = new SqlCommand();
                cm.Connection = cn;
                cm.CommandType = CommandType.StoredProcedure;
                cm.CommandText = "SP_Hospital";
                cm.Parameters.AddWithValue("@Action", "VD");
                da = new SqlDataAdapter(cm);
                dt = new DataTable();
                da.Fill(dt);
                var Hospital = (from DataRow dr in dt.Rows
                                select new PatientDetailsEntity()
                                {
                                    Doct_Name = dr["Doct_Name"].ToString(),
                                    Insurance_Name = dr["Insurance_Name"].ToString(),
                                    Insurance_Scheme_Name= dr["Insurance_Scheme_Name"].ToString(),
                                    Patient_Name= dr["Patient_Name"].ToString(),
                                    Admission_Date= dr["Admission_Date"].ToString(),
                                    Discharge_Date= dr["Discharge_Date"].ToString(),
                                    Insured_amount= Convert.ToDecimal(dr["Insured_amount"].ToString()),
                                    Total_Expenses= Convert.ToDecimal(dr["Total_Expenses"].ToString()),
                                    Patient_ID = Convert.ToInt32(dr["Patient_ID"].ToString()),
                                    Total_Payble_Amount = Convert.ToDecimal(dr["Total_Payble_Amount"].ToString())
                                }).ToList();
                cn.Close();
                return Hospital;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<int> Insert(PatientDetailsEntity obj)
        {
            try
            {
                int Str_RetValue = 0;
                var cn = CreateConnection();
                if (cn.State == ConnectionState.Closed) cn.Open();
                cm = new SqlCommand();
                cm.Connection = cn;
                cm.CommandType = CommandType.StoredProcedure;
                cm.CommandText = "SP_Hospital";
                cm.Parameters.AddWithValue("@Action", "I");
                cm.Parameters.AddWithValue("@Patient_ID", obj.Patient_ID);
                cm.Parameters.AddWithValue("@Admission_Date", obj.Admission_Date);
                cm.Parameters.AddWithValue("@Discharge_Date", obj.Discharge_Date);
                cm.Parameters.AddWithValue("@Total_Expenses", obj.Total_Expenses);
                SqlParameter par;
                par = cm.Parameters.Add("@PMSG_OUT", SqlDbType.Int, 50);
                par.Direction = System.Data.ParameterDirection.Output;
                cm.ExecuteNonQuery();
                cn.Close();
                Str_RetValue = (int)cm.Parameters["@PMSG_OUT"].Value;
                return Str_RetValue;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        public async Task<PatientDetailsEntity> FillCertificate(int id)
        {
            try
            {
                var cn = CreateConnection();
                if (cn.State == ConnectionState.Closed) cn.Open();
                cm = new SqlCommand();
                cm.Connection = cn;
                cm.CommandType = CommandType.StoredProcedure;
                cm.CommandText = "SP_Hospital";
                cm.Parameters.AddWithValue("@Action", "CD");
                cm.Parameters.AddWithValue("@Patient_ID", id);
                da = new SqlDataAdapter(cm);
                dt = new DataTable();
                da.Fill(dt);
                var Patient = (from DataRow dr in dt.Rows
                               select new PatientDetailsEntity()
                               {
                                   Doct_Name = dr["Doct_Name"].ToString(),
                                   Insurance_Name = dr["Insurance_Name"].ToString(),
                                   Insurance_Scheme_Name = dr["Insurance_Scheme_Name"].ToString(),
                                   Patient_Name = dr["Patient_Name"].ToString(),
                                   Admission_Date = dr["Admission_Date"].ToString(),
                                   Discharge_Date = dr["Discharge_Date"].ToString(),
                                   Insured_amount = Convert.ToDecimal(dr["Insured_amount"].ToString()),
                                   Total_Expenses = Convert.ToDecimal(dr["Total_Expenses"].ToString()),
                                   Total_Payble_Amount = Convert.ToDecimal(dr["Total_Payble_Amount"].ToString()),
                                   Patient_ID = Convert.ToInt32(dr["Patient_ID"].ToString()),
                                   Doct_ID = Convert.ToInt32(dr["Doct_ID"].ToString()),
                                   Hosp_ID = Convert.ToInt32(dr["Hosp_ID"].ToString()),
                                   Hosp_Name = dr["Hosp_Name"].ToString()
                               }).FirstOrDefault();
                cn.Close();
                return Patient;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
