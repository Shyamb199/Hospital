﻿using HOSPITAL_INSURANCECLAIM_SCHEME.Models;
using HOSPITAL_INSURANCECLAIM_SCHEME.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HOSPITAL_INSURANCECLAIM_SCHEME.Services
{
    public class InsuranceClaimService:IInsuranceClaimService
    {
        private readonly IInsuranceClaimRepository _insurance;
        public InsuranceClaimService(IInsuranceClaimRepository insurance)
        {
            _insurance = insurance;
        }

        public async Task<PatientDetailsEntity> FillCertificateService(int id)
        {
            return await _insurance.FillCertificate(id);
        }

        public async Task<List<PatientDetailsEntity>> GetDetailsService()
        {
            return await _insurance.GetDetails();
        }

        public async Task<List<DoctorEntity>> GetDoctorService(int Hosp_ID)
        {
            return await _insurance.GetDoctor(Hosp_ID);
        }

        public async Task<List<HospitalEntity>> GetHospitalService()
        {
            return await _insurance.GetHospital();
        }

        public async Task<InsuranceEntity> GetInsuranceDetailService(int Patient_ID)
        {
            return await _insurance.GetInsuranceDetail(Patient_ID);
        }

        public async Task<List<PatientEntity>> GetPatientService(int Doct_ID)
        {
            return await _insurance.GetPatient(Doct_ID);
        }

        public async Task<int> InsertService(PatientDetailsEntity obj)
        {
            return await _insurance.Insert(obj);
        }
    }
}
