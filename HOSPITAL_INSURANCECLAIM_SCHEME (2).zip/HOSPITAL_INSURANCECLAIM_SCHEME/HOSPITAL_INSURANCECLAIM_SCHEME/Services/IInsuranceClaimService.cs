﻿using HOSPITAL_INSURANCECLAIM_SCHEME.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HOSPITAL_INSURANCECLAIM_SCHEME.Services
{
    public interface IInsuranceClaimService
    {
        Task<List<HospitalEntity>> GetHospitalService();
        Task<List<DoctorEntity>> GetDoctorService(int Hosp_ID);
        Task<List<PatientEntity>> GetPatientService(int Doct_ID);
        Task<InsuranceEntity> GetInsuranceDetailService(int Patient_ID);
        Task<List<PatientDetailsEntity>> GetDetailsService();
        Task<int> InsertService(PatientDetailsEntity obj);
        Task<PatientDetailsEntity> FillCertificateService(int id);
    }
}
