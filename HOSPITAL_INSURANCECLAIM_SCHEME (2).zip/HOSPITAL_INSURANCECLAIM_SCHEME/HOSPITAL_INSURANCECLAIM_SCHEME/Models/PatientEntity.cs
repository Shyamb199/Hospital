﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HOSPITAL_INSURANCECLAIM_SCHEME.Models
{
    public class PatientEntity
    {
        public int Patient_ID { get; set; }
        public int Doct_ID { get; set; }
        public string Patient_Name { get; set; }
        public string Patient_Phone { get; set; }
        public int Insurance_Scheme_ID { get; set; }
        public string Status { get; set; }
    }
}
