﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HOSPITAL_INSURANCECLAIM_SCHEME.Models
{
    public class HospitalEntity
    {
        public int Hosp_ID { get; set; }
        public string Hosp_Name { get; set; }
    }
}
