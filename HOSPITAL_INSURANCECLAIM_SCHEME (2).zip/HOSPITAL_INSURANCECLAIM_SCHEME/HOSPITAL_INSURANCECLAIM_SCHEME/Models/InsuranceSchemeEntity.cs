﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HOSPITAL_INSURANCECLAIM_SCHEME.Models
{
    public class InsuranceSchemeEntity
    {
        public int Insurance_Scheme_ID { get; set; }
        public int Insurance_ID { get; set; }
        public string Insurance_Scheme_Name { get; set; }
        public Decimal Insurance_Percentage_cover { get; set; }
    }
}
