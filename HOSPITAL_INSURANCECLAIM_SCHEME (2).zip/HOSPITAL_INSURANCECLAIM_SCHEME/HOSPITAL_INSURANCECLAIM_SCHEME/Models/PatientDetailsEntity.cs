﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HOSPITAL_INSURANCECLAIM_SCHEME.Models
{
    public class PatientDetailsEntity
    {
        public int Patient_Details_ID { get; set; }
        public int Patient_ID { get; set; }
        public int Hosp_ID { get; set; }
        public string Hosp_Name { get; set; }
        public int Doct_ID { get; set; }
        public string Admission_Date { get; set; }
        public string Discharge_Date { get; set; }
        public Decimal Total_Expenses { get; set; }
        public Decimal Insured_amount { get; set; }
        public Decimal Total_Payble_Amount { get; set; }
        public string Insurance_Name { get; set; }
        public string Doct_Name { get; set; }
        public string Insurance_Scheme_Name { get; set; }
        public string Patient_Name { get; set; }
    }
}
