﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace HOSPITAL_INSURANCECLAIM_SCHEME.Models
{
    public class InsuranceEntity
    {
        public int Insurance_ID { get; set; }
        public string Insurance_Name { get; set; }

        [NotMapped]
        public string Insurance_Scheme_Name { get; set; }
    }
}
